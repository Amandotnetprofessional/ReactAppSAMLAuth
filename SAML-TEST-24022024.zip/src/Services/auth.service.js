const API_URL = 'https://localhost:7291/api';
const ALLOWED_ORIGINS = [
  'https://localhost:7291',
  'http://localhost:3000',
  'http://localhost:4200',
  'http://localhost:4201',
  'http://dev.aws.averisource.com'
];

const openPopupWindow = (url, name, width = 800, height = 600) => {
  const left = (window.innerWidth - width) / 2 + window.screenX;
  const top = (window.innerHeight - height) / 2 + window.screenY;
  
  return window.open(
    url,
    name,
    `width=${width},height=${height},left=${left},top=${top},status=0,toolbar=0,menubar=0,location=0`
  );
};

export const initiateSamlLogin = () => {
  return new Promise((resolve, reject) => {
    let messageReceived = false;
    
    const popup = openPopupWindow(
      `${API_URL}/saml/proxy-login`,
      'SAMLLogin'
    );

    if (!popup) {
      throw new Error('POPUP_BLOCKED');
    }

    const handleMessage = (event) => {
      console.log('Received message from:', event.origin);
      console.log('Message data:', event.data);

      // Check if the origin is allowed
      if (!ALLOWED_ORIGINS.includes(event.origin)) {
        console.log('Message received from unexpected origin:', event.origin);
        // Continue processing as the message might be valid
      }

      if (event.data) {
        messageReceived = true;
        window.removeEventListener('message', handleMessage);
        clearInterval(checkPopup);
        resolve(event.data);
      }
    };

    window.addEventListener('message', handleMessage);

    const checkPopup = setInterval(() => {
      if (popup?.closed) {
        clearInterval(checkPopup);
        window.removeEventListener('message', handleMessage);
        
        if (!messageReceived) {
          console.log('Popup closed without receiving message');
          reject(new Error('LOGIN_CANCELLED'));
        }
      }
    }, 500);
  });
};

export const initiateSamlLogout = async (userEmail) => {
  alert(userEmail)
  if (!userEmail) {
    console.warn('No email provided for logout');
    userEmail = JSON.parse(localStorage.getItem('user'))?.email || '';
  }

  const url = `${API_URL}/saml/proxy-logout?email=${encodeURIComponent(userEmail)}`;
  
  return new Promise((resolve, reject) => {
    let messageReceived = false;
    const popup = openPopupWindow(url, 'SAMLLogout');

    if (!popup) {
      throw new Error('POPUP_BLOCKED');
    }

    const handleMessage = (event) => {
      console.log('Received logout message:', event.data);

      if (event.data?.type === 'LOGOUT_SUCCESS') {
        messageReceived = true;
        window.removeEventListener('message', handleMessage);
        clearInterval(checkPopup);
        
        // Clear local storage
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        
        resolve(true);
      }
    };

    window.addEventListener('message', handleMessage);

    const checkPopup = setInterval(() => {
      if (popup?.closed) {
        clearInterval(checkPopup);
        window.removeEventListener('message', handleMessage);
        
        if (!messageReceived) {
          // Even if we don't get the message, we should still clear local storage
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          resolve(true);
        }
      }
    }, 500);
  });
};

// Helper function to check if popups are blocked
export const checkPopupsBlocked = () => {
  const popup = openPopupWindow('about:blank', 'popupTest', 1, 1);
  const blocked = !popup;
  
  if (popup) {
    popup.close();
  }
  
  return blocked;
};